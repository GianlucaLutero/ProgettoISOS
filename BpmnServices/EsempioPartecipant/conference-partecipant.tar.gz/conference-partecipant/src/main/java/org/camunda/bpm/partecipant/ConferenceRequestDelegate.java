package org.camunda.bpm.partecipant;

import java.util.logging.Logger;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;



public class ConferenceRequestDelegate implements JavaDelegate {
	
	 private final static Logger LOGGER = Logger.getLogger("CONFERENCE-REQUEST");

	public void execute(DelegateExecution execution) throws Exception {
		LOGGER.info("Porco dio dammi le conferenze");
	}

}
