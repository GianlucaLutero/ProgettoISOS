@javax.xml.bind.annotation.XmlSchema(namespace = "org.camunda.bpm.ExternalService.xsd")
package org.camunda.bpm.ExternalService;
