package org.camunda.bpm.partecipant;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

public class ReservationDetailsPaymentDelegate implements JavaDelegate {

	private final static Logger LOGGER = Logger.getLogger("Sended-Reservation-Details-Payment");
	
	Map<String, Object> varList;
	
	Object name_Reservation;
	Object surname_Reservation;
	Object job_Reservation;
	Object sex_Reservation;
	Object addres_Reservation;
	
	public void execute(DelegateExecution execution) throws Exception {		
		// TODO Auto-generated method stub
		
		varList = new HashMap<String, Object>();	
		
		name_Reservation = execution.getVariable("name_Detail_Reservatiom");
		surname_Reservation = execution.getVariable("surname_Detail_Reservatiom");
		job_Reservation = execution.getVariable("job_Detail_Reservatiom");
		sex_Reservation = execution.getVariable("sex_Detail_Reservatiom");
		addres_Reservation = execution.getVariable("addres_Detail_Reservatiom");
		
		varList.put("name_Detail_Reservatiom", name_Reservation);
		varList.put("surname_Detail_Reservatiom", surname_Reservation);
		varList.put("job_Detail_Reservatiom", job_Reservation);
		varList.put("sex_Detail_Reservatiom", sex_Reservation);
		varList.put("addres_Detail_Reservatiom", addres_Reservation);
		
		
		
		RuntimeService runtimeService = execution.getProcessEngineServices().getRuntimeService();
		runtimeService.correlateMessage("reservationDetails", new HashMap<String, Object>(), varList);
		
		 LOGGER.info("Sending reservation details and payment ");
	}

}
