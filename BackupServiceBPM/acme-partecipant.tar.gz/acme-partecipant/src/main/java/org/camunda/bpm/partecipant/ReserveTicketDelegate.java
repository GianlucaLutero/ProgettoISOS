package org.camunda.bpm.partecipant;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

public class ReserveTicketDelegate implements JavaDelegate {
	
	private final static Logger LOGGER = Logger.getLogger("Reserve-Ticket");

	Map<String, Object> varList;
	
	Object chosenConference;
	Object stop;
	
	public void execute(DelegateExecution execution) throws Exception {
		// TODO Auto-generated method stub
		
		varList = new HashMap<String, Object>();	
		
		chosenConference = execution.getVariable("chosenConference");
		stop = execution.getVariable("stop");
		
		varList.put("chosenConference",chosenConference);
		varList.put("stop", stop);

		 RuntimeService runtimeService = execution.getProcessEngineServices().getRuntimeService();
		 runtimeService.correlateMessage("reservationRequest", new HashMap<String, Object>(), varList);
		 
		 LOGGER.info("sending ticket reservation");
		
	}

}
