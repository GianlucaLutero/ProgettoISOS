package org.camunda.bpm.partecipant;

import java.util.logging.Logger;

import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

public class RetrayPaymentDelegate implements JavaDelegate{

	private final static Logger LOGGER = Logger.getLogger("Retray-Payment");
	
	public void execute(DelegateExecution execution) throws Exception {
		// TODO Auto-generated method stub
		

		 RuntimeService runtimeService = execution.getProcessEngineServices().getRuntimeService();
		 runtimeService.correlateMessage("responseRetryPayment");
		 
		 LOGGER.info("sending retry");
		
	}

}
