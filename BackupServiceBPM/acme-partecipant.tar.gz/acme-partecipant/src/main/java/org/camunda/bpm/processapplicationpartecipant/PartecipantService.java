package org.camunda.bpm.processapplicationpartecipant;

import org.camunda.bpm.application.ProcessApplication;
import org.camunda.bpm.application.impl.ServletProcessApplication;

//@ProcessApplication("Partecipant Service App")
public class PartecipantService extends ServletProcessApplication {

}

