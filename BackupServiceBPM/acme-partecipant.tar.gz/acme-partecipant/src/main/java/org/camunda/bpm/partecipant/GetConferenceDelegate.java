package org.camunda.bpm.partecipant;

import java.util.HashMap;
import java.util.Map;
import java.util.logging.Logger;

import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

public class GetConferenceDelegate implements JavaDelegate {
	
	private final static Logger LOGGER = Logger.getLogger("Conference-Created");

	Map<String, Object> partecipantId;
	
	public void execute(DelegateExecution execution) throws Exception {
		// TODO Auto-generated method stub
		
		partecipantId = new HashMap<String, Object>();
		
		partecipantId.put("partecipantKey", execution.getBusinessKey());
		
		 RuntimeService runtimeService = execution.getProcessEngineServices().getRuntimeService();
		
		 //runtimeService.createMessageCorrelation("conferencesListRequest");
		 runtimeService.correlateMessage("conferencesListRequest", "platform", partecipantId);
		 
		 LOGGER.info("sending responce");
		 	 
	}

}
