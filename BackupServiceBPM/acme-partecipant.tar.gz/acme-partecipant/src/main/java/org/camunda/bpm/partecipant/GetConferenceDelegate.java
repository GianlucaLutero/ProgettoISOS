package org.camunda.bpm.partecipant;

import java.util.logging.Logger;

import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

public class GetConferenceDelegate implements JavaDelegate {
	
	private final static Logger LOGGER = Logger.getLogger("Conference-Created");

	public void execute(DelegateExecution execution) throws Exception {
		// TODO Auto-generated method stub
		
		 RuntimeService runtimeService = execution.getProcessEngineServices().getRuntimeService();
		
		 //runtimeService.createMessageCorrelation("conferencesListRequest");
		 runtimeService.correlateMessage("conferencesListRequest");
		 
		 LOGGER.info("sending responce");
		 	 
	}

}
