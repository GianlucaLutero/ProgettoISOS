package org.camunda.bpm.DelegateACME;

import java.util.logging.Logger;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

public class DecreasingHoldingAvaibleDelegate implements JavaDelegate {
	
	private final static Logger LOGGER = Logger.getLogger("Decreasing-Holdings-Avaible");
	

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		//Nel database tolgo un posto alla conferenza
		
		LOGGER.info("Decreasing avaible tickets in: ");
	}

}
