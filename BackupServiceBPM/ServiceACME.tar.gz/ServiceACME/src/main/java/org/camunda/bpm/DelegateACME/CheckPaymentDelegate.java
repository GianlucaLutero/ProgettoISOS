package org.camunda.bpm.DelegateACME;

import java.util.logging.Logger;

import org.camunda.bpm.ExternalService.BankService;
import org.camunda.bpm.ExternalService.BankServiceService;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

public class CheckPaymentDelegate implements JavaDelegate {

	private final static Logger LOGGER = Logger.getLogger("Check-Payment");
	
	@Override
	public void execute(DelegateExecution execution) throws Exception {
		LOGGER.info("Retrievin last payment");
		
		BankService bank = new BankServiceService().getBankServiceServicePort();
		
		String res = bank.checkAccount("conference");
		
		if(checkBankResponse(res)) {
			LOGGER.info("payment accepted");
			execution.setVariable("payment", "accepted");
		}else {
			LOGGER.info("payment denied");
			execution.setVariable("payment", "denied");
		}

	}
	
	private boolean checkBankResponse(String payments) {
		return true;
	}

}
