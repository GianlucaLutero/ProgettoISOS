package org.camunda.bpm.DelegateACME;

import java.util.logging.Logger;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.camunda.bpm.utility.DatabaseService;

public class SavePaymentInvoiceDelegate implements JavaDelegate {
	
	private final static Logger LOGGER = Logger.getLogger("Save-Invoice");


	@Override
	public void execute(DelegateExecution execution) throws Exception {
		LOGGER.info("Saving invoice");
		
		DatabaseService db = new DatabaseService();
		
		db.insertInvoice((String)execution.getVariable("invoice_name"),
				(String)execution.getVariable("invoice_details"),
				(String)execution.getVariable("invoice_address"),
				new Long((long)execution.getVariable("invoice_amount")).intValue(),
				(String)execution.getVariable("details_conference_name"));

		
		
	}

}
