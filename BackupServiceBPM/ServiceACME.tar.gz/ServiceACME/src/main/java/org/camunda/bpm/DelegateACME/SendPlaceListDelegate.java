package org.camunda.bpm.DelegateACME;

import java.util.HashMap;
import java.util.logging.Logger;

import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.camunda.bpm.engine.variable.Variables;
import org.camunda.bpm.engine.variable.value.ObjectValue;


public class SendPlaceListDelegate implements JavaDelegate {
	
	private final static Logger LOGGER = Logger.getLogger("Send-Conference-List");
	private HashMap<String, Object> variables = new HashMap<String,Object>();


	@Override
	public void execute(DelegateExecution execution) throws Exception {
		
		LOGGER.info("Preparing data");
		
		String conferences = (String) execution.getVariable("conferences");
		
		
		
		//variables.put("places", conferences);
		
		LOGGER.info("Conference found :"+conferences);
		
		ObjectValue typedList = Variables.objectValue(conferences).serializationDataFormat("application/json").create();
		
	//	execution.setVariable("places", typedList);
		
		variables.put("places", typedList);
		
		
		
		LOGGER.info("Place list:"+typedList);
		
		RuntimeService runtimeService = execution.getProcessEngineServices().getRuntimeService();
		
		runtimeService.correlateMessage("responsePlaceList", new HashMap<String,Object>(), variables);
		
		LOGGER.info("Place sended");

	}

}
