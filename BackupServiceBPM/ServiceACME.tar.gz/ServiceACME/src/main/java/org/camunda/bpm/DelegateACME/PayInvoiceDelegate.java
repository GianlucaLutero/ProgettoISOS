package org.camunda.bpm.DelegateACME;

import java.util.logging.Logger;

import org.camunda.bpm.ExternalService.BankService;
import org.camunda.bpm.ExternalService.BankServiceService;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.camunda.bpm.utility.DatabaseService;

public class PayInvoiceDelegate implements JavaDelegate {
	
	private final static Logger LOGGER = Logger.getLogger("Pay-Invoice");


	@Override
	public void execute(DelegateExecution execution) throws Exception {
		BankService bankService = new BankServiceService().getBankServiceServicePort();
		DatabaseService databaseService = new DatabaseService();
		
		LOGGER.info("Paying invoice");
		bankService.payment("conference", (int)execution.getVariable("invoice_amount"), (String)execution.getVariable("invoice_address"));
		LOGGER.info("Updating balance");
		databaseService.updateBalance((String)execution.getVariable("details_conference_name"), (int)execution.getVariable("invoice_amount"));
	
	}

}
