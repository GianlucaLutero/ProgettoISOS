package org.camunda.bpm.utility;

import java.util.ArrayList;

import org.camunda.bpm.engine.impl.util.json.JSONArray;

public class DummyDatabase {
	
	private static ArrayList<String> conferencePlaces = new ArrayList<String>() {{
		add("{\"name\":\"Fiere di Parma\", \"location\":\"Parma\",\"phone\":\"052100000\",\"capacity\":100}");
		add("{\"name\":\"Fiere di Bologna\", \"location\":\"Bologna\",\"phone\":\"052100000\",\"capacity\":100}");
		add("{\"name\":\"Centro congressi\", \"location\":\"Forli\",\"phone\":\"052100000\",\"capacity\":1}");
		add("{\"name\":\"Campo rom\", \"location\":\"Pescara\",\"phone\":\"052100000\",\"capacity\":10000000000000}");
	}};
	
	private static ArrayList<String> conferenceActive = new ArrayList<String>() {{
		add("{\"name\\\":\"Bla Bla Bla\"}");
	}};
	/*
	 * conferenze 
	 * |- nome
	 * |- luogo 
	 * |- telefono
	 * |- capacita
	 */
	public static String getPlaces() {
		
		//JSONArray list = new JSONArray();
		
	//	list.put(conferencePlaces);
		
	//	return list;
		String list = "[";
		
		for(String p:conferencePlaces) {
			list += p+",";
			
		}
		list+="{\"test\":true}]";
		
		return list;
		
	}

}
