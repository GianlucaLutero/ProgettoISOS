package org.camunda.bpm.DelegateACME;

import java.util.HashMap;
import java.util.logging.Logger;

import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.camunda.bpm.utility.DatabaseService;

public class ActivatePlatformDelegate implements JavaDelegate {

	private final static Logger LOGGER = Logger.getLogger("Activate-Platform");
	private HashMap<String, Object> variables = new HashMap<String,Object>();

	
	@Override
	public void execute(DelegateExecution execution) throws Exception {
		LOGGER.info("Sending creation platform message");
		
		RuntimeService runtimeService = execution.getProcessEngineServices().getRuntimeService();
		
		//runtimeService.startProcessInstanceByMessage("activatedPlatform");
		variables.put("name", execution.getVariable("details_conference_name"));
		variables.put("object", execution.getVariable("details_conference_object"));
		variables.put("date", execution.getVariable("details_conference_date"));
		variables.put("end_date", execution.getVariable("datails_conference_end_date"));
		variables.put("location", execution.getVariable("details_conference_location"));
		variables.put("desc", execution.getVariable("details_conference_desc"));
		variables.put("catering", execution.getVariable("catering"));
		variables.put("conference_place", execution.getVariable("conference_place"));
		variables.put("capacity", 100);
		variables.put("bkey", execution.getBusinessKey());
		/*
		 * Salvo la conferenza nel db
		 */
		
		
		//Get variable from form
		//DatabaseService db = new DatabaseService();
		//db.insertConference(nome, object_conference, emailconference_description, location, price, conference_date, end_date, reserved);
		
		runtimeService.correlateMessage("activatedPlatform","platform",variables);
	
		LOGGER.info("Sended creation platform message");
		
	}

}
