package org.camunda.bpm.DelegateACME;

import java.util.logging.Logger;

import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

public class ActivatePlatformDelegate implements JavaDelegate {

	private final static Logger LOGGER = Logger.getLogger("Activate-Platform");
	
	@Override
	public void execute(DelegateExecution execution) throws Exception {
	
		LOGGER.info("Sending creation platform message");
		
		RuntimeService runtimeService = execution.getProcessEngineServices().getRuntimeService();
		
		//runtimeService.startProcessInstanceByMessage("activatedPlatform");
		
		runtimeService.correlateMessage("activatedPlatform");
		LOGGER.info("Sended creation platform message");
		
	}

}
