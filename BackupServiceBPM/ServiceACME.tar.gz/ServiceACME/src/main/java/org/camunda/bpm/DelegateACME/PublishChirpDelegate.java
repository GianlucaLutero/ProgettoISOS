package org.camunda.bpm.DelegateACME;

import java.util.logging.Logger;

import org.camunda.bpm.ExternalService.ChirpterService;
import org.camunda.bpm.ExternalService.ChirpterServiceService;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.camunda.bpm.utility.DatabaseService;

public class PublishChirpDelegate implements JavaDelegate {

	private final static Logger LOGGER = Logger.getLogger("Publish-Chirp");
	
	@Override
	public void execute(DelegateExecution execution) throws Exception {
		
		LOGGER.info("Publishing chirp");
		
		ChirpterService cs = new ChirpterServiceService().getChirpterServiceServicePort();
		
		cs.publish((String)execution.getVariable("message"), "conference", (String)execution.getVariable("stream_id"));
		LOGGER.info("Chirp published");
	}

}
