package org.camunda.bpm.DelegateACME;

import java.util.HashMap;
import java.util.logging.Logger;

import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

public class SendCreationNotificationDelegate implements JavaDelegate {
	
	private final static Logger LOGGER = Logger.getLogger("Send-Creation-Notification");
	private HashMap<String, Object> variables = new HashMap<String,Object>();


	@Override
	public void execute(DelegateExecution execution) throws Exception {
		LOGGER.info("Platform created");
		
        RuntimeService runtimeService = execution.getProcessEngineServices().getRuntimeService();
        variables.put("platform_created", 1);
		runtimeService.correlateMessage("responseACMEPlatformCreation",execution.getBusinessKey(),variables);
		
		LOGGER.info("Platform notification sended");

	}

}
