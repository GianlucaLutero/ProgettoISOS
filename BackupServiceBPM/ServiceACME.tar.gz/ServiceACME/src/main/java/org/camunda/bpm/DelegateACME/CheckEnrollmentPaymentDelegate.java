package org.camunda.bpm.DelegateACME;

import java.util.logging.Logger;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.camunda.bpm.utility.DatabaseService;

public class CheckEnrollmentPaymentDelegate implements JavaDelegate {
	
	private final static Logger LOGGER = Logger.getLogger("Check-Enrollment-Payment");

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		
		LOGGER.info("Retrieving conference name");
		
		String cName = (String)execution.getVariable("details_conference_name");
		
		LOGGER.info("Retrieving invoice amount");
		//String invoiceName = (String)execution.getVariable("invoice_name");
		
		long invoiceAmount = (long)execution.getVariable("invoice_amount");
		
		int total = 0;
		
		DatabaseService db = new DatabaseService();
		total = db.getConferenceBalance(cName);
		
		LOGGER.info("Checking conference data");
		
		execution.setVariable("cost", new Long(invoiceAmount).intValue());
		execution.setVariable("total", total);
		

	}

}
