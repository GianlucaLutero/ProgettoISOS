package org.camunda.bpm.DelegateACME;

import java.util.ArrayList;
import java.util.logging.Logger;

import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.camunda.bpm.engine.impl.util.json.JSONArray;
import org.camunda.bpm.utility.DummyDatabase;

public class SearchConferenceSpaceDelegate implements JavaDelegate {
	
	private final static Logger LOGGER = Logger.getLogger("Search-Conference-Space");

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		
		LOGGER.info("Loading conference spaces");
		
		//JSONArray confList = DummyDatabase.getPlaces();
		
		//RuntimeService runtimeService = execution.getProcessEngineServices().getRuntimeService();
		
		String confList = DummyDatabase.getPlaces();
		
		
		execution.setVariable("conferences", confList);
		
		LOGGER.info("Conference space loaded: "+confList);
		
		//execution.setVariable("conferences", confList);

	}

}
