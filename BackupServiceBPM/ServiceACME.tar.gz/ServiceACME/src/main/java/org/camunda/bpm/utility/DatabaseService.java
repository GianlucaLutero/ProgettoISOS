package org.camunda.bpm.utility;

import java.io.UnsupportedEncodingException;
import java.security.MessageDigest;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class DatabaseService extends DatabaseAbstractManager{
	public void insertConference(String nome,String object_conference, String emailconference_description, String location, int price, String conference_date, String end_date, int reserved){
        
		Connection connection = null;
		PreparedStatement statement = null;
		
		
		try{
			connection = databaseConnect();
			statement = connection.prepareStatement("insert into conference values(?,?,?,?,?,?,?)");
			statement.setString(1,nome);
			statement.setString(2,object_conference);
			statement.setString(3, emailconference_description);
			statement.setString(4, location);
			statement.setInt(5,price);
			statement.setString(6,conference_date);
			statement.setString(7,end_date);
			statement.setInt(8,reserved);
			statement.executeUpdate();
		}catch(SQLException s){
		    databaseDisconnect(connection,statement);
		    s.printStackTrace();
		}
	}	
		
	public void insertPartecipant(String nome,String surname, String job, String sex, String addres){

		Connection connection = null;
		PreparedStatement statement = null;


		try{
			connection = databaseConnect();
			statement = connection.prepareStatement("insert into conference values(?,?,?,?,?)");
			statement.setString(1,nome);
			statement.setString(2,surname);
			statement.setString(3, job);
			statement.setString(4, sex);
			statement.setString(5,addres);
			statement.executeUpdate();
		}catch(SQLException s){
			databaseDisconnect(connection,statement);
			s.printStackTrace();
		}


	}
	
	
	public void insertInvoice(String nome, String details, String addres, int ammount,String conference){

		Connection connection = null;
		PreparedStatement statement = null;


		try{
			connection = databaseConnect();
			statement = connection.prepareStatement("insert into invoice values(?,?,?,?,?)");
			statement.setString(1, nome);
			statement.setString(2, details);
			statement.setString(3, addres);
			statement.setInt(4, ammount);
			statement.setString(5, conference);
			statement.executeUpdate();
		}catch(SQLException s){
			databaseDisconnect(connection,statement);
			s.printStackTrace();
		}


	}
	
	
	public void updateIncrementReservation(String nome){
 
		Connection connection = null;
		PreparedStatement statement = null;


		try{
			connection = databaseConnect();
			statement = connection.prepareStatement("update conference set reserved = reserved + 1 where name = ?");
			statement.setString(1, nome);
			statement.executeUpdate();
		}catch(SQLException s){
			databaseDisconnect(connection,statement);
			s.printStackTrace();
		}


	}
	
	// Occhio non vada in negativo
	public void updatedecrementtReservation(String nome){
		 
		Connection connection = null;
		PreparedStatement statement = null;


		try{
			connection = databaseConnect();
			statement = connection.prepareStatement("update conference set reserved = reserved - 1 where name = ?");
			statement.setString(1, nome);
			statement.executeUpdate();
		}catch(SQLException s){
			databaseDisconnect(connection,statement);
			s.printStackTrace();
		}


	}
	
	public int getConferenceBalance(String name) {
	
		Connection connection = null;
		PreparedStatement statement = null;
		int balance = 0;

		try{
			connection = databaseConnect();
			statement = connection.prepareStatement("select balance from conference where name = ?");
			statement.setString(1, name);
			
			ResultSet res = statement.executeQuery();
			
			while(res.next()) {
				balance = res.findColumn("balance");
			}
			
		}catch(SQLException s){
			databaseDisconnect(connection,statement);
			s.printStackTrace();
		}		
		
		return balance;
	}
	
	
	public void updateBalance(String name,int value) {
		Connection connection = null;
		PreparedStatement statement = null;

		try{
			connection = databaseConnect();
			statement = connection.prepareStatement("update conference set balance = balance - ? where name = ?");
			statement.setInt(1, value);
			statement.setString(2, name);
			statement.executeUpdate();
		}catch(SQLException s){
			databaseDisconnect(connection,statement);
			s.printStackTrace();
		}
	}
	
	public int getPendingInvoiceAmount(String conference) {

		Connection connection = null;
		PreparedStatement statement = null;
		int balance = 0;

		try{
			connection = databaseConnect();
			statement = connection.prepareStatement("select sum(amount) as balance from invoice where name = ?");
			statement.setString(1, conference);
			
			ResultSet res = statement.executeQuery();
			
			while(res.next()) {
				balance = res.getInt("balance");
			}
			
		}catch(SQLException s){
			databaseDisconnect(connection,statement);
			s.printStackTrace();
		}		
		
		return balance;
		
	}
	
	public String getPlaces() {
		String places = "[";
		
		Connection connection = null;
		PreparedStatement statement = null;
		

		try{
			connection = databaseConnect();
			statement = connection.prepareStatement("select * from places  order by rand() limit 3");
			
			ResultSet res = statement.executeQuery();
			
			if(res.next()) {

				res.beforeFirst();
				while(res.next()) {
					places += "{\"name\":\""+res.getString("name")+
							"\", \"location\":\""+res.getString("location")+
							"\",\"phone\":\""+res.getString("phone")+
							"\",\"capacity\":\""+res.getString("capacity")+"\"},";
				}

				places = places.substring(0,places.length()-1) + "]";
				
			}else {
				
				places += "]";
				
			}
		}catch(SQLException s){
			databaseDisconnect(connection,statement);
			s.printStackTrace();
		}		
		
		return places;
	}
	
	public String getCatering() {
		String places = "[";
		
		Connection connection = null;
		PreparedStatement statement = null;
		

		try{
			connection = databaseConnect();
			statement = connection.prepareStatement("select * from catering");
			
			ResultSet res = statement.executeQuery();
			
			while(res.next()) {
				places += "{\"name\":\""+res.getString("name")+
						"\", \"phone\":\""+res.getString("phone")+
						"\",\"email\":\""+res.getString("email")+"\"},";
			}
			
			places = places.substring(0,places.length()-1) + "]";
			
		}catch(SQLException s){
			databaseDisconnect(connection,statement);
			s.printStackTrace();
		}		
		
		return places;		
	}

}
