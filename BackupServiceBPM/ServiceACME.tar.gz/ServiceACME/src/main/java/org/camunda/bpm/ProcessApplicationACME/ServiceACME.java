package org.camunda.bpm.ProcessApplicationACME;

import org.camunda.bpm.application.ProcessApplication;
import org.camunda.bpm.application.impl.ServletProcessApplication;

@ProcessApplication("ACME Service App")
public class ServiceACME extends ServletProcessApplication {

}
