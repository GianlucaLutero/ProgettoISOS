package org.camunda.bpm.DelegateACME;

import java.util.logging.Logger;

import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

public class ConferenceDeniedDelegate implements JavaDelegate {
	
	private final static Logger LOGGER = Logger.getLogger("Conference-Denied");

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		
		LOGGER.info("Conference Denied - Sending Message to Client");
		
		RuntimeService runtimeService = execution.getProcessEngineServices().getRuntimeService();
	
		runtimeService.correlateMessage("negativeResponseForConferenceCreation");
		
		LOGGER.info("Sending response to client");
		

	}

}
