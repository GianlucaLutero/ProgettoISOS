package org.camunda.bpm.DelegateACME;

import java.util.logging.Logger;

import org.camunda.bpm.ExternalService.ChirpterService;
import org.camunda.bpm.ExternalService.ChirpterServiceService;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.camunda.bpm.engine.impl.util.json.JSONObject;

public class CreateChirpStreamDelegate implements JavaDelegate {
	
	private final static Logger LOGGER = Logger.getLogger("Create-Chirp-Stream");

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		
		String result;
		
		LOGGER.info("Creating new chirpstream");
		
		ChirpterService cs = new ChirpterServiceService().getChirpterServiceServicePort();
		
		result = cs.createChirpStream("The conference is hosted by ACME", "conference", "dummy");
		JSONObject jo = new JSONObject(result);
		
		LOGGER.info("Chirpstream id: "+jo.get("id").toString());
		
		execution.setVariable("stream_id", jo.get("id"));
		execution.setVariable("message", "Benvenuti");
		LOGGER.info("Chirpstream created");

	}

}
