package org.camunda.bpm.DelegateACME;

import java.util.logging.Logger;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.camunda.bpm.engine.impl.util.json.JSONArray;
import org.camunda.bpm.engine.impl.util.json.JSONObject;

public class SelectConferenceDelegate implements JavaDelegate {
	
	private final static Logger LOGGER = Logger.getLogger("Select-Conference");

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		
		String conf = (String)execution.getVariable("conferences");
		
		JSONArray c = new JSONArray(conf);
		
		JSONObject selected = (JSONObject)c.get(0);
		
		execution.setVariable("location", selected.toString());
		
		LOGGER.info("Selected conference place: "+selected.toString());
		
		//execution.setVariable("", value);

	}

}
