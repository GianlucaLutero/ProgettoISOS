package org.camunda.bpm.DelegateACME;

import java.util.HashMap;
import java.util.logging.Logger;

import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

public class RequestMoneyDelegate implements JavaDelegate{
	

	private final static Logger LOGGER = Logger.getLogger("Request-Money");
	private HashMap<String, Object> variables = new HashMap<>();
	
	
	@Override
	public void execute(DelegateExecution execution) throws Exception {
		
		LOGGER.info("Retrieving payment data");
		
		int bal = -1 * (int)execution.getVariable("balance");
		
		variables.put("acme_name", "ACME");
		variables.put("acme_amount", bal);
	
		RuntimeService runtimeService = execution.getProcessEngineServices().getRuntimeService();
		runtimeService.correlateMessage("paymentOffRequest", execution.getBusinessKey(), variables);
		LOGGER.info("Payment request sended");
	}

}
