package org.camunda.bpm.DelegateACME;

import java.util.logging.Logger;

import org.camunda.bpm.ExternalService.BankService;
import org.camunda.bpm.ExternalService.BankServiceService;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

public class PayClientDelegate implements JavaDelegate {
	
	private final static Logger LOGGER = Logger.getLogger("Pay-Client");

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		
		LOGGER.info("Retrieving client data");
		
		int bal = (int)execution.getVariable("balance");
		String name = (String)execution.getVariable("client_name");
		BankService bank = new BankServiceService().getBankServiceServicePort();
		LOGGER.info("Sending "+ bal + " to "+name);
		bank.payment("conference",bal , name);
	}

}
