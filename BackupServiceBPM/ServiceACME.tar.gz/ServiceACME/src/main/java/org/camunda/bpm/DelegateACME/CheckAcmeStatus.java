package org.camunda.bpm.DelegateACME;

import java.util.logging.Logger;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

public class CheckAcmeStatus implements JavaDelegate {
	
	private final static Logger LOGGER = Logger.getLogger("ACME-Status-Check");

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		
		String sta = "ok";
		
		LOGGER.info("Checking ACME status ....");
		
		execution.setVariable("status", sta);
		
		LOGGER.info("ACME Status is "+ sta);
		

	}

}
