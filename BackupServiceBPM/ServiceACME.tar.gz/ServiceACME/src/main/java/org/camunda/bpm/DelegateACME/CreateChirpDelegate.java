package org.camunda.bpm.DelegateACME;

import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Logger;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.asm.commons.StaticInitMerger;

public class CreateChirpDelegate implements JavaDelegate {
	

	private final static Logger LOGGER = Logger.getLogger("Create-Chirp");
	private static DelegateExecution delExec;
	
	@Override
	public void execute(DelegateExecution execution) throws Exception {
		
		LOGGER.info("Creating chirp to publish");
		delExec = execution;
		// Setta la varibile di processo per il timer della data con 2 giorni di anticipo
		// Crea i chirp da pubblicare
		
		execution.setVariable("relevant_date", "PT2M");
		Timer time = new Timer();
		
		TimerTask t = new TimerTask() {

		
			@Override
			public void run() {
				LOGGER.info("Settato nuovo timer (Non e' vero)");
			//	e.setVariable("relevant_date", "PT6M");
				updateVariable();
				time.cancel();	
			}
		};
		
		
		time.schedule(t, 2*60*1000);
		
		

	}
	
	public void updateVariable() {
		delExec.setVariable("relevant_date", "PT6M");
	}

}
