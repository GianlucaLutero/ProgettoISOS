package org.camunda.bpm.DelegateACME;

import java.util.Timer;
import java.util.TimerTask;
import java.util.logging.Logger;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.springframework.asm.commons.StaticInitMerger;

public class CreateChirpDelegate implements JavaDelegate {
	

	private final static Logger LOGGER = Logger.getLogger("Create-Chirp");
	private static DelegateExecution delExec;
	
	@Override
	public void execute(DelegateExecution execution) throws Exception {
		String date = (String)execution.getVariable("relevant_date");
		LOGGER.info("Creating chirp to publish");	
		
		if(date.equals("PT1M")) {
			execution.setVariable("message", "La conferenza inizia");
			execution.setVariable("relevant_date", "PT3M");
		}
		else {
			execution.setVariable("relevant_date", "PT1M");
		}
		
		

	}
	

}
