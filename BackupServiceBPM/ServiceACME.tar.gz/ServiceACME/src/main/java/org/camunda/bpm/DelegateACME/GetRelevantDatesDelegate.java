package org.camunda.bpm.DelegateACME;

import java.util.logging.Logger;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

public class GetRelevantDatesDelegate implements JavaDelegate {
	
	private final static Logger LOGGER = Logger.getLogger("Get-Relevant-Dates");

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		LOGGER.info("Retrieving relevant dates of conference");
		
		// Leggo dal database le date rilevanti
		
		execution.setVariable("relevant_date", "PT9M");

	}

}
