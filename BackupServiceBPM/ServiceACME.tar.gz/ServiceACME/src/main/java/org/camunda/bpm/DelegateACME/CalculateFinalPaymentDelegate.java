package org.camunda.bpm.DelegateACME;

import java.util.logging.Logger;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

public class CalculateFinalPaymentDelegate implements JavaDelegate {
	
	private final static Logger LOGGER = Logger.getLogger("Calculate-Final-Payment");


	@Override
	public void execute(DelegateExecution execution) throws Exception {
		
		LOGGER.info("Calculating final payment");

	}

}
