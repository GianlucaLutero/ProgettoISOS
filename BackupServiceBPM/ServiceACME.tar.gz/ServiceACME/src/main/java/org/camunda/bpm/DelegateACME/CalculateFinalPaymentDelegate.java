package org.camunda.bpm.DelegateACME;

import java.util.logging.Logger;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.camunda.bpm.utility.DatabaseService;

public class CalculateFinalPaymentDelegate implements JavaDelegate {
	
	private final static Logger LOGGER = Logger.getLogger("Calculate-Final-Payment");
	private final static int acmeFee = 100;


	@Override
	public void execute(DelegateExecution execution) throws Exception {
		
		LOGGER.info("Calculating final payment");
		
		DatabaseService db = new DatabaseService();
		
		int bal = db.getConferenceBalance((String)execution.getVariable("details_conference_name"));
		
		int pending = db.getPendingInvoiceAmount((String)execution.getVariable("details_conference_name"));
		LOGGER.info("Pending invoices amount: "+pending);
		
		execution.setVariable("balance", bal - acmeFee - pending);
		
	}

}
