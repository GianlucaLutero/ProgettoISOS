package org.camunda.bpm.DelegateACME;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.logging.Logger;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.camunda.bpm.engine.impl.util.json.JSONArray;
import org.camunda.bpm.engine.impl.util.json.JSONObject;
import org.camunda.bpm.utility.DatabaseService;

public class SearchCateringDelegate implements JavaDelegate {

	private final static Logger LOGGER = Logger.getLogger("Search-Catering-Delegate");
	private  URL url;
	
	@Override
	public void execute(DelegateExecution execution) throws Exception {
		
		/*
		 * Setto le variabili per la richiesta
		 */
		
		String place = (String)execution.getVariable("location");
		DatabaseService db = new DatabaseService();
		
		String catList = db.getCatering();
		LOGGER.info("Posto scelto: "+place);
		LOGGER.info("Catering partner: "+catList);
		
		//String rawUrl = "http://localhost:8002/getNearestPlace?place=\""+place+"\"&placeList="+catList;
		place = java.net.URLEncoder.encode(place,"UTF-8");
		String rawUrl = java.net.URLEncoder.encode(catList,"UTF-8");
		LOGGER.info("Encoding url: "+catList);
		url  = new URL("http://localhost:8002/getNearestPlace?place=\""+place+"\"&placeList="+rawUrl);
		LOGGER.info("Getting page from url: "+url);
		
		HttpURLConnection con = (HttpURLConnection) url.openConnection();

		// optional default is GET
		con.setRequestMethod("GET");

		int responseCode = con.getResponseCode();
		LOGGER.info("\nSending 'GET' request to URL : " + url);
		LOGGER.info("Response Code : " + responseCode);
		
		BufferedReader in = new BufferedReader(
		        new InputStreamReader(con.getInputStream()));
		String inputLine;
		StringBuffer response = new StringBuffer();

		while ((inputLine = in.readLine()) != null) {
			response.append(inputLine);
		}
		in.close();

		//print result
		
		String cateringSelected = response.substring(response.indexOf("<location>")+10, response.indexOf("</location>"));
		//String cateringSelected = response.toString();
		
		LOGGER.info("Gis response: "+cateringSelected);
		
		execution.setVariable("cateringSelected", cateringSelected);
		/*
		 * setto la variabile per larisposta
		 */
	}

}
