package org.camunda.bpm.DelegateACME;

import java.util.logging.Logger;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

public class UpdateHoldingAvaibleDelegate implements JavaDelegate {
	
	private final static Logger LOGGER = Logger.getLogger("Updating-Holdings-Avaible");

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		// Nel database riaggiungo il posto tolto in precedenza
		
		LOGGER.info("Adding tickets in: ");

	}

}
