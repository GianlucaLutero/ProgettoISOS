package org.camunda.bpm.DelegateACME;

import java.util.logging.Logger;

import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.camunda.bpm.utility.DatabaseService;

public class UpdateHoldingAvaibleDelegate implements JavaDelegate {
	
	private final static Logger LOGGER = Logger.getLogger("Updating-Holdings-Avaible");

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		// Nel database riaggiungo il posto tolto in precedenza
		
		String confName = (String) execution.getVariable("prova");
		DatabaseService db = new DatabaseService();
		
		db.updateIncrementReservation(confName);
		
		LOGGER.info("Adding tickets in: "+confName);

	}

}
