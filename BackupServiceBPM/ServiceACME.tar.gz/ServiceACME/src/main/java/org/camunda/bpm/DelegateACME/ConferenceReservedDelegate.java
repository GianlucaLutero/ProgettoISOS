package org.camunda.bpm.DelegateACME;

import java.util.logging.Logger;

import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

public class ConferenceReservedDelegate implements JavaDelegate {
	
	private final static Logger LOGGER = Logger.getLogger("Conference-Created");

	@Override
	public void execute(DelegateExecution execution) throws Exception {
		
		LOGGER.info("A new conference has been created");
		
		//JSONArray confList = DummyDatabase.getPlaces();
		
		//execution.setVariable("places", confList);
		
		RuntimeService runtimeService = execution.getProcessEngineServices().getRuntimeService();
		
		runtimeService.correlateMessage("positiveResponseForConferenceCreation");
		
		LOGGER.info("Sending response to client");

	}

}
