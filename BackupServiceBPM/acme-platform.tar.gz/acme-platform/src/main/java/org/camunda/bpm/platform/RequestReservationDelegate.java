package org.camunda.bpm.platform;

import java.util.logging.Logger;

import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

public class RequestReservationDelegate implements JavaDelegate {
	
	private final static Logger LOGGER = Logger.getLogger("REQUEST-RESERVATION-DELEGATE");

	public void execute(DelegateExecution execution) throws Exception {
		
		//int n_capacity = execution.getVariable();
		int n_capacity = 100;
		
		n_capacity = n_capacity - 1;
		
		//n_capacity = execution.setVariable(, n_capacity);
		
		
		RuntimeService runtimeService = execution.getProcessEngineServices().getRuntimeService();
		runtimeService.correlateMessage("reservationPlatformRequest");
		
		//runtimeService.correlateMessage(""); // message intermedi
		//runtimeService.createMessageCorrelation("nome messaggio").correlateStartMessage() // messaggi per gli start
		
		
	}

}
