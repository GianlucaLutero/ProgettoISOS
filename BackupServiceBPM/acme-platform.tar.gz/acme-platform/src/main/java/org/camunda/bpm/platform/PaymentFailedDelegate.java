package org.camunda.bpm.platform;

import java.util.logging.Logger;

import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

public class PaymentFailedDelegate implements JavaDelegate {
	
	private final static Logger LOGGER = Logger.getLogger("PAYMENT-FAILED-DELEGATE");

	public void execute(DelegateExecution execution) throws Exception {
		

		
		RuntimeService runtimeService = execution.getProcessEngineServices().getRuntimeService();
		runtimeService.correlateMessage("paymentReservationFailed");
		
		//runtimeService.correlateMessage(""); // message intermedi
		//runtimeService.createMessageCorrelation("nome messaggio").correlateStartMessage() // messaggi per gli start
		
		
	}


}
