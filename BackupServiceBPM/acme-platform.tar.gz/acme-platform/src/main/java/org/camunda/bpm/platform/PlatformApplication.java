package org.camunda.bpm.platform;

import org.camunda.bpm.application.ProcessApplication;
import org.camunda.bpm.application.impl.ServletProcessApplication;

@ProcessApplication("Platform Service App")
public class PlatformApplication extends ServletProcessApplication {

}
