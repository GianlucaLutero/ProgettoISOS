package org.camunda.bpm.platform;

import java.util.HashMap;

import java.util.logging.Logger;

import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

public class CreatePlatformDelegate implements JavaDelegate {
	
	private final static Logger LOGGER = Logger.getLogger("CREATE-PLATFORM-REQUEST");

	public void execute(DelegateExecution execution) throws Exception {
		
		RuntimeService runtimeService = execution.getProcessEngineServices().getRuntimeService();
		runtimeService.correlateMessage("responsePlatformCreation");

	}

}
