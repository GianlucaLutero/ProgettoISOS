package org.camunda.bpm.utility;

import java.util.ArrayList;

public class DummyDatabase {
	
	private static ArrayList<String> conferenceList = new ArrayList<String>() {{
		
		add("{\"name\":\"zeus\", \"objectconference\":\"martin garrix\", \"conferencedescription\":\"si volaaa\", \"location\": \"Parma\", \"conferencedate\": \"2 febbraio\",  \"price\": \"500\", \"enddate\": \"3 febbraio\"}");
		add("{\"name\":\"gesu\", \"objectconference\":\"queen\", \"conferencedescription\":\"bohemian rhapsody\", \"location\": \"Sbt\", \"conferencedate\": \"5 febbraio\",  \"price\": \"1500\", \"enddate\": \"6 febbraio\"}");
		add("{\"name\":\"budda\", \"objectconference\":\"guns\", \"conferencedescription\":\"dont cry\", \"location\": \"Civitanova\", \"conferencedate\": \"8 febbraio\",  \"price\": \"2500\", \"enddate\": \"7 febbraio\"}");
		add("{\"name\":\"ateo\", \"objectconference\":\"acdc\", \"conferencedescription\":\"le galline con le spine\", \"location\": \"Palermo\", \"conferencedate\": \"12 febbraio\",  \"price\": \"3500\", \"enddate\": \"13 febbraio\"}");
		
		
		//add("{\"name\":\"dio\", \"object conference\":\"ciao\", \"conference description\":\"samb\", \"location\": \"Roma\", \"conference date\": 5 febbraio}");
		//add("{\"name\":\"gesu\", \"object conference\":\"porca troia\", \"conference description\":\"stadio\", \"location\": \"San benedetto del tronto\", \"conference date\": 8 febbraio}");
		//add("{\"name\":\"budda\", \"object conference\":\"daje\", \"conference description\":\"avanzi di balera\", \"location\": \"Bologna\", \"conference date\": 10 febbraio}");
		//add("{\"name\":\"budda\"}");
		//add("{\"name\":\"gesu\"}");
	}
	
	/*
	 nome
	 oggetto conferenza
	 descrizione conferenza
	 location
	 conference date
	*/

};

public static String getList(){
	

String list	= "[";

for(String p:conferenceList) {
	list += p+",";
}
	
list+="{\"test\":true}]";

//return conferenceList;

return list;
}

}
