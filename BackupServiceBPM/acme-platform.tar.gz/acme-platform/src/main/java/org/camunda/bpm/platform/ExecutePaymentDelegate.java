package org.camunda.bpm.platform;

import java.util.logging.Logger;

import org.camunda.bpm.ExternalService.BankService;
import org.camunda.bpm.ExternalService.BankServiceService;
import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

public class ExecutePaymentDelegate implements JavaDelegate {
	
	private final static Logger LOGGER = Logger.getLogger("EXECUTE-PAYMENT-DELEGATE");

	public void execute(DelegateExecution execution) throws Exception {
		
		
	BankService bk = new BankServiceService().getBankServiceServicePort();
	
	bk.payment("sbt", 30, "filippo");
		
		

		boolean payment_reservation  = true;
		
		
		if(payment_reservation = true)
		LOGGER.info("pagamento accettato");
		else
		LOGGER.info("pagamento non accettato");	
		
		
		//RuntimeService runtimeService = execution.getProcessEngineServices().getRuntimeService();
		//runtimeService.correlateMessage("executeReservationPayment");
		
		//runtimeService.correlateMessage(""); // message intermedi
		//runtimeService.createMessageCorrelation("nome messaggio").correlateStartMessage() // messaggi per gli start
		
		
	}

}
