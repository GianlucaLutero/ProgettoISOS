package org.camunda.bpm.platform;

import java.util.HashMap;
import java.util.logging.Logger;

import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

public class CheckAvailabilityDelegate implements JavaDelegate {
	
	private final static Logger LOGGER = Logger.getLogger("CHECK-AVAILABILITY-DELEGATE");
	private HashMap<String, Object> variables = new HashMap<String, Object>();

	public void execute(DelegateExecution execution) throws Exception {
		
		
		boolean check_available  = true;
		
		
		if(check_available == true)
		LOGGER.info("si vola");
		else
		LOGGER.info("non si vola");	
		
		execution.setVariable("check_available", check_available);
		
		variables.put("check_available", check_available);
		
		
		RuntimeService runtimeService = execution.getProcessEngineServices().getRuntimeService();
		runtimeService.correlateMessage("checkAvailibility", new HashMap<String, Object>(), variables);
		
		//runtimeService.correlateMessage(""); // message intermedi
		//runtimeService.createMessageCorrelation("nome messaggio").correlateStartMessage() // messaggi per gli start
		
		
	}

}
