package org.camunda.bpm.platform;

import java.util.HashMap;
import java.util.logging.Logger;

import org.camunda.bpm.ExternalService.BankService;
import org.camunda.bpm.ExternalService.BankServiceService;
import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

public class CheckPaymentDelegate implements JavaDelegate {
	
	private final static Logger LOGGER = Logger.getLogger("CHECK-PAYMENT-DELEGATE");


	public void execute(DelegateExecution execution) throws Exception {
		
		BankService bk = new BankServiceService().getBankServiceServicePort();
		
		bk.checkAccount("crisso");
		
		
		boolean payment_reservation  = true;
		
		
		if(payment_reservation == true)
		LOGGER.info("si vola");
		else
		LOGGER.info("non si vola");	
		
		execution.setVariable("payment_reservation", payment_reservation);
		
		
		//RuntimeService runtimeService = execution.getProcessEngineServices().getRuntimeService();
		//runtimeService.correlateMessage("responsePlatformCreation");

	}
	
	

}
