package org.camunda.bpm.platform;

import java.util.ArrayList;
import java.util.HashMap;

import java.util.logging.Logger;

import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;
import org.camunda.bpm.utility.DummyDatabase;

public class SendConferenceListDelegate implements JavaDelegate {
	
	private final static Logger LOGGER = Logger.getLogger("SEND-CONFERENCE-DELEGATE");
	private HashMap<String, Object> variables = new HashMap<String, Object>();

	public void execute(DelegateExecution execution) throws Exception {
		
		//SETTARE LA VARIABILE PER LA LISTA DELLE CONFERENZE
		//listaconferenze = execution.setVariable()
		
		
		String conferenceList = DummyDatabase.getList();

		
		variables.put("conferenceList", conferenceList);
		
		
		RuntimeService runtimeService = execution.getProcessEngineServices().getRuntimeService();
		runtimeService.correlateMessage("sendConferenceList", new HashMap<String, Object>(), variables);
		
		//runtimeService.correlateMessage("sendConferenceList");
		
		
		
		
		//runtimeService.correlateMessage(""); // message intermedi
		//runtimeService.createMessageCorrelation("nome messaggio").correlateStartMessage() // messaggi per gli start
		
		
	}
}
