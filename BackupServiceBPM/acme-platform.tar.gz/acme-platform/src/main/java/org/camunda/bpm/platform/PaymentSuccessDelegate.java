package org.camunda.bpm.platform;

import java.util.logging.Logger;

import org.camunda.bpm.engine.RuntimeService;
import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

public class PaymentSuccessDelegate implements JavaDelegate {
	
	private final static Logger LOGGER = Logger.getLogger("PAYMENT-SUCCESS-DELEGATE");

	public void execute(DelegateExecution execution) throws Exception {
		

		
		RuntimeService runtimeService = execution.getProcessEngineServices().getRuntimeService();
		runtimeService.correlateMessage("paymentReservationSuccess");
		
		//runtimeService.correlateMessage(""); // message intermedi
		//runtimeService.createMessageCorrelation("nome messaggio").correlateStartMessage() // messaggi per gli start
		
		
	}

}
