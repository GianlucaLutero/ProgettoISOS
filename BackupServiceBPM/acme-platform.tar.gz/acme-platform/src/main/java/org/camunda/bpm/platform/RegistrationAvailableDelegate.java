package org.camunda.bpm.platform;

import java.util.logging.Logger;


import org.camunda.bpm.engine.delegate.DelegateExecution;
import org.camunda.bpm.engine.delegate.JavaDelegate;

public class RegistrationAvailableDelegate implements JavaDelegate {
	
	private final static Logger LOGGER = Logger.getLogger("CHECK-REGISTRTION-AVAILABLE");

	public void execute(DelegateExecution execution) throws Exception {
		
		boolean check_registration_available  = true;
		
		
		if(check_registration_available == true) {
		LOGGER.info("si vola");
		execution.setVariable("check_registration_available", true);
		}
		else
		{
		LOGGER.info("non si vola");
		execution.setVariable("check_registration_available", false);
		}
	}

}
